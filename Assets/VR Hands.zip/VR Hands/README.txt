How to use
==========
1 - Import the "VR Hands" folder to your XR project.  There should be an LHand and RHand prefab in the top level folder.
2 - Set the XR Left and Right hand controllers by copying the prefabs to their respective controllers:
	XR Rig->LeftHand Controller->XR Controller (Action-based)->Model Prefab
	XR Rig->RightHand Controller->XR Controller (Action-based)->Model Prefab
3 - If you need to adjust the attach point for the hand, open the LHand or RHand prefab and tweak the transform of the "Hand" child object.

